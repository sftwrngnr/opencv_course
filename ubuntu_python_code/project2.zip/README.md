Homework submission for week 2.
Prerequisites:
1. opencv2
2. python3.10 or greater

Instructions:
To execute the program type the following command:
python3 submission.py
The output file will be written to output/face.jpg
If no area is selected, no output file will be created.

